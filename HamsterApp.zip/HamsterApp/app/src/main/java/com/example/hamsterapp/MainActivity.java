package com.example.hamsterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt1 = (TextView) findViewById(R.id.txtC);

        Intent i = new Intent(this, Activity1Activity.class);

        new CountDownTimer(10000,1000)
        {
            @Override
            public void onTick(long l) { txt1.setText("COMENZANDO EN "+l/1000); }

            @Override
            public void onFinish() {

                txt1.setText("LISTO");
                startActivity(i);
            }
        }.start();
    }
}